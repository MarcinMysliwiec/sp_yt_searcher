YT_MAX_RESULTS = 5
YT_BASE_URL = 'https://youtube.com'

FILE_DIR = 'download'
FILE_EXT = 'mp3'

BONUS_RATES = {
    'OFFICIAL': .5,
    'REMIX': .5,
    'INSTRUMENTAL': .5,
    'LIVE': .5,
    'CHANNEL': .3
}
